// eslint-disable-next-line no-unused-vars
import React, { useState } from "react";
import axios from "axios";
import styles from "./AddEmail.module.css";

// eslint-disable-next-line react/prop-types
const AddEmail = ({ onClose }) => {
  const [email, setEmail] = useState("");
  const token = localStorage.getItem("token");
  const [step, setStep] = useState(1);

  const handleAddEmail = async () => {
    try {
      await axios({
        method: "post",
        // eslint-disable-next-line no-undef
        url:  `http://localhost:3000/api/task/addEmail/${taskId}`,
        headers: { Authorization: `${token}` },
        data: { email },
      });
      setStep(2);
    } catch (error) {
      console.error("Error adding email:", error);
    }
  };

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.modalContent}>
        {step === 1 && (
          <div>
            <h4>Add people to the board</h4>
            <input
              type="email"
              placeholder="Enter the email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={styles.input}
            />
            <div className={styles.modalButtons}>
              <button onClick={() => onClose()} className={styles.cancelButton}>
                Cancel
              </button>
              <button
                onClick={() => handleAddEmail()}
                className={styles.addButton}
              >
                Add Email
              </button>
            </div>
          </div>
        )}
        {step === 2 && (
          <div className={styles.resultEmail}>
            <h2>{email} added to the board</h2>
            <button onClick={() => onClose()} className={styles.confirmButton}>
              Okay, got it!
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AddEmail;
